import java.util.Scanner;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class SaisieDonnees {

    static Scanner scanner = new Scanner(System.in);

    public static int Menu() {
        // Menu du programme
        System.out.println("Que voulez vous faire ? ");
        System.out.println("-Taper 1 pour ajouter une salle:");
        System.out.println("-Taper 2 pour modifier une salle:");
        System.out.println("-Taper 3 pour supprimer une salle:");
        System.out.println("-Taper 4 pour ajouter une reservation:");
        System.out.println("-Taper 5 pour supprimer une reservation:");
        System.out.println("-Taper 6 pour afficher les créneaux libres:");
        System.out.println("-Taper 7 pour afficher les reservation:");
        System.out.println("-Taper 8 afficher le détail d'une reservation:");
        System.out.println("-Taper 0 pour fermer le programme:");
        int choix = scanner.nextInt();
        return choix;
    }

    public static void EntreeInfos() {
        String batiment;
        int etage;				
        int numero;
        int heure_init;
        int heure_final;
        int date;				
        int heuredebut;				
        int heurefin;

        try {
            // Tester la connexion
            Connection connection = DatabaseConnection.getConnection();
            System.out.println("Connexion réussie !");
            
            switch (Menu()) {
                case 0:
                    //System.out.println("Jeudi");
                    break;
                case 1:
                    // Ajout salle
                    System.out.println("Taper le nom du batiment.");
                    batiment = scanner.next();
                    System.out.println("Taper le numéro de l'étage.");
                    etage = scanner.nextInt();				
                    System.out.println("Taper le numéro de salle.");
                    numero = scanner.nextInt();
                    //ajouter_salle(batiment,etage,numero);
                    // Exécution de la requête
                    Statement statement = connection.createStatement();
                    //ResultSet resultSet = 
                    statement.executeQuery("insert into salle (batiment,etage,numero) values (\""+ batiment +"\", "+ etage +", "+ numero +");");
                    break;
                case 2:
                    // Modif salle
                    System.out.println("Taper le nom du batiment actuel.");
                    batiment = scanner.next();				
                    System.out.println("Taper le numéro de l'étage actuel.");
                    etage = scanner.nextInt();				
                    System.out.println("Taper le numéro de salle actuel.");
                    numero = scanner.nextInt();				
                    System.out.println("Taper le nouveau nom du batiment .");
                    String newbatiment = scanner.next();				
                    System.out.println("Taper le nouveau numéros de l'étage.");
                    int newetage = scanner.nextInt();				
                    System.out.println("Taper le nouveau numéros de salle.");
                    int newnumero = scanner.nextInt();
                    //modifier_salle(batiment,etage,numero,newbatiment,newetage,newnumero);
                    Statement query1 = connection.createStatement();
                    ResultSet reslt_query1 = query1.executeQuery("select `id` from `gestion_salle`.`salle` where batiment=\""+batiment+"\" and etage="+etage+" and numero="+numero+";");
                    while (reslt_query1.next()) {
                        int id = reslt_query1.getInt(1);
                        query1.executeQuery("UPDATE `gestion_salle`.`salle` SET `batiment`=\""+newbatiment+"\", `etage`="+newetage+", `numero`="+newnumero+" WHERE `id`="+id+";");
                    }
                    break;
                case 3:
                    // Suppr salle
                    System.out.println("Taper le nom du batiment à supprimer.");
                    batiment = scanner.next();				
                    System.out.println("Taper le numéros de l'étage à supprimer.");
                    etage = scanner.nextInt();				
                    System.out.println("Taper le numéros de salle à supprimer.");
                    numero = scanner.nextInt();
                    //supprimer_salle(batiment,etage,numero);
                    Statement query2 = connection.createStatement();
                    ResultSet reslt_query2 = query2.executeQuery("select `id` from `gestion_salle`.`salle` where batiment=\""+batiment+"\" and etage="+etage+" and numero="+numero+";");
                    while (reslt_query2.next()) {
                        int id = reslt_query2.getInt(1);
                        query2.executeQuery("DELETE FROM `gestion_salle`.`salle` WHERE  `id`="+id+";");
                    }
                    break;
                case 4:
                    // Ajout reservation
                    System.out.println("Taper le nom du batiment.");
                    batiment = scanner.next();				
                    System.out.println("Taper le numéros de l'étage.");
                    etage = scanner.nextInt();				
                    System.out.println("Taper le numéros de salle.");
                    numero = scanner.nextInt();				
                    System.out.println("Taper la date JJMMAA.");
                    date = scanner.nextInt();				
                    System.out.println("Taper l'heure de début.");
                    heuredebut = scanner.nextInt();				
                    System.out.println("Taper l'heure de fin.");
                    heurefin = scanner.nextInt();
                    System.out.println("Taper le nom de la promo.");
                    String promo = scanner.next();
                    System.out.println("Taper le nom du responsable.");
                    String responsable = scanner.next();
                    //ajouter_reservation(date,heuredebut,heurefin,promo, responsable,batiment,etage ,numero );
                    break;
                case 5:
                    // Suppr reservation
                    /*System.out.println("Taper le nom du batiment.");
                    batiment = scanner.next();				
                    System.out.println("Taper le numéros de l'étage.");
                    etage = scanner.nextInt();				
                    System.out.println("Taper le numéros de salle.");
                    numero = scanner.nextInt();				
                    System.out.println("Taper la date JJMMAA.");
                    date = scanner.nextInt();				
                    System.out.println("Taper l'heure de début.");
                    heuredebut = scanner.nextInt();				
                    //supprimer_reservation(date,heuredebut, batiment,etage , numero );*/
                    break;
                case 6:
                    // Affich créneaux libres
                    System.out.println("De");
                    heure_init = scanner.nextInt();				
                    System.out.println("à");
                    heure_final = scanner.nextInt();				
                    //afficher_libre(heure_init, heure_final);
                    break;
                case 7:
                    // List reservations
                    System.out.println("De");
                    heure_init = scanner.nextInt();				
                    System.out.println("à");
                    heure_final = scanner.nextInt();				
                    //liste_reservation(heure_init, heure_final);
                    break;
                case 8:
                    // Détails reservation
                    System.out.println("Taper le nom du batiment.");
                    batiment = scanner.next();				
                    System.out.println("Taper le numéros de l'étage.");
                    etage = scanner.nextInt();				
                    System.out.println("Taper le numéros de salle.");
                    numero = scanner.nextInt();				
                    System.out.println("Taper la date JJMMAA.");
                    date = scanner.nextInt();				
                    System.out.println("Taper l'heure de début.");
                    heuredebut = scanner.nextInt();					
                    // detail_reservation(date,heuredebut,batiment,etage,numero);
                    break;
                default:
                    System.out.println("Saisie invalide");
            }
            
            scanner.close();
            // Fermer la connexion (à faire dans une section 'finally' dans une application réelle)
            connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    //scanner.close();
}

//public static int load(String file) { //Liste au lieux de int
//	int list = 0; //récupére les id dans une liste
//	return list; 
